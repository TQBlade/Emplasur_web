package com.emplasur.backend_inventario.dto;

public interface TopProductoDTO {
    String getNombre();
    Long getCantidad();
    Double getTotal();
}